<template>
    <div class="relative">
        <slot />
    </div>
</template>

<script>
	export default {
		name: 'PopoverWrapper',
	}
</script>
