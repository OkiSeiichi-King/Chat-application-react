## Version 1.0.2
#### Release date: 9. May 2022
- Improved sanitization for .env values to prevent crash your app
- Improved reCaptcha validation errors
- Fixed issue when upload doesn't start after you drag the file into empty view
- Fixed trash navigator issue

## Version 1.0.1
#### Release date: 8. May 2022
- Fixed issue with chunk upload

## Version 1.0.0
#### Release date: 1. May 2022
- Release