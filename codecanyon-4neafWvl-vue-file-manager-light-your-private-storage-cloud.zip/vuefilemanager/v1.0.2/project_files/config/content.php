<?php

return [
    'content' => [
        'regular' => [
            [
                'name'  => 'allowed_recaptcha',
                'value' => 0,
            ],
        ],
        'extended' => [

        ],
    ],
];
