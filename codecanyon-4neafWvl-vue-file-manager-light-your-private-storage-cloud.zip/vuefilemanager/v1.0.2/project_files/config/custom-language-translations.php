<?php

/*
 * Place here your custom translations for your project.
 * These translation will be automatically seeded after you
 * run setup:dev script or installing app via Setup Wizard Tool
 */

return [
    'custom' => 'translation',
];
